<template>
  <div>问答</div>
</template>

<script>
export default {}
</script>

<style></style>
